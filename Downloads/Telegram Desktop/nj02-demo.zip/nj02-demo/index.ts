// Kiểu dữ liệu string
let myString: string = "Hello, TypeScript!";

// Kiểu dữ liệu number
let myNumber: number = 42;

// Kiểu dữ liệu boolean
let myBoolean: boolean = true;

// Kiểu dữ liệu bigint (phải có hậu tố 'n' cho các số lớn)
let myBigInt: bigint = 9007199254740991n;

// Kiểu dữ liệu undefined (thường sử dụng cho biến chưa được khởi tạo giá trị)
let myUndefined: undefined = undefined;

// Kiểu dữ liệu null
let myNull: null = null;

// Kiểu dữ liệu symbol (sử dụng cho các giá trị duy nhất)
let mySymbol: symbol = Symbol("uniqueIdentifier");

// Hiển thị các giá trị trên console
// console.log("String:", myString);
// console.log("Number:", myNumber);
// console.log("Boolean:", myBoolean);
// console.log("BigInt:", myBigInt);
// console.log("Undefined:", myUndefined);
// console.log("Null:", myNull);
// console.log("Symbol:", mySymbol);

let n = 1; // type inference

let strOrNum: string | number | boolean = true;

if (typeof strOrNum === 'boolean') {
  console.log('this is bolean');
}

console.log(typeof strOrNum);

// Object Shape
type Company = {
  name: string;
  location: string;
  isProgrammer: boolean;
};

// const first
const company: Company = {
  name: '200Lab',
  location: 'here',
  isProgrammer: true
};

function add(x: number, y: number): number {
  return x + y;
}

const addArrow = (x: number, y: number): number => x + y;


function doVoid(): void { }

const doVoidArrow = (): void => { };

class Cat {
  // name: string;
  // age: number;
  // age!: number // tôi khẳng định là khi dùng age sẽ có dữ liệu

  constructor(readonly name: string, public age: number) { }

  eat(): void {
    console.log(`${this.name} is eating`);
  }

  afterAYear(): void {
    this.age += 1;
  }
}

const moCat = new Cat('Mo', 2);
console.log(moCat, moCat.name, moCat.age, moCat.eat());

abstract class Animal {
  constructor(readonly name: string) { }

  abstract eat(): void;
}

class Dog extends Animal {
  eat(): void {
    console.log('pate');
  }
}

const myDog: Animal = new Dog('Too');
myDog.eat();

abstract class MyElement {
  abstract render(): string;
}

function engine(nodes: MyElement[]): string[] {
  return nodes.map(n => n.render());
}

class ImageElement extends MyElement {
  render(): string {
    return 'image';
  }
}

class TextElement extends MyElement {
  render(): string {
    return 'text';
  }
}

class HyperText extends TextElement {
  // override
  render(): string {
    return 'hyper-text';
  }
}

const result = engine([new ImageElement(), new TextElement(), new HyperText()]);
console.log(result);

class CarEngine {
  public start() {
    this.step1();
    this.step2();
    this.step3();
  }

  private step1() { }
  private step2() { }
  private step3() { }
}

const myCarEngine = new CarEngine();
myCarEngine.start();