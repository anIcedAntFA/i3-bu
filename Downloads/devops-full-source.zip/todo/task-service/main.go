package main

import "demo-service/cmd"

func main() {
	cmd.Execute()
}
