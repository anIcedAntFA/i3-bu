package common

const (
	KeyCompMySQL = "mysql"
	KeyCompGIN   = "gin"
	KeyCompJWT   = "jwt"
	KeyCompConf  = "config"

	MaskTypeUser = 1
	MaskTypeTask = 2
)
