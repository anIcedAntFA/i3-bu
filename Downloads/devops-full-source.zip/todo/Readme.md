# Huớng dẫn cài đặt

1. Cài đặt Docker và Docker Compose
2. Chạy lệnh `docker-compose up --build -d`

    ``` bash
    docker-compose up --build -d
    ```

3. Truy cập vào `http://localhost` để sử dụng và `http://localhost:8080` sử dụng API Gateway
4. Đăng ký tài khoản và sử dụng
5. Chúc bạn một ngày tốt lành!

